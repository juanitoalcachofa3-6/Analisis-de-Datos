import pandas as pd
import matplotlib.pyplot as plt

# Leer el archivo de una semana específica
df=pd.read_csv("datos_filtrados_semana_1.csv")

df['datetime'] = pd.to_datetime(df['D'] + ' ' + df['H'], format='%d-%m-%Y %H:%M')

# Grafica Temperatura y Presión
fig, ax1 = plt.subplots(figsize=(12, 6))

# T
ax1.set_xlabel('Fecha y Hora')
ax1.set_ylabel('T', color='blue')
ax1.plot(df['datetime'], df['T'], 'b-', linewidth=1, label='Temperatura')
ax1.tick_params(axis='y', labelcolor='blue')
ax1.grid(True, alpha=0.3)

# P
#ax2 = ax1.twinx()
#ax2.set_ylabel('P', color='red')
#ax2.plot(df['datetime'], df['P'], 'r-', linewidth=1, label='Presión')
#ax2.tick_params(axis='y', labelcolor='red')

plt.title('Temperatura y Presión')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
