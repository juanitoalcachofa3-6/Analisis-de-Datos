import pandas as pd
from datetime import datetime, timedelta
import glob

# El periodo de tiempo que queremos tratar es del 20 de enero de 2025 (el primer lunes que pudo tomar datos escaramujo) al 25 de enero de este año (el último domingo antes de la catastrofe del sensor) 

fecha_ini = datetime.strptime('2025-01-20 00:00', '%Y-%m-%d %H:%M')
fecha_fin = datetime.strptime('2026-01-25 23:59', '%Y-%m-%d %H:%M')

# Lo primero que hay que hacer es leer el archivo, en este caso nomás leemos uno pero tú ya tienes la idea de poder concatenar, te dejo uno de ejemplo y piensa cómo puedes unirlos
archivos = glob.glob('/home/danykruger/Documentos/datos_pyt/*.txt')
data_list = []
for archivo in archivos:
    df_temp = pd.read_csv(archivo, sep=r"\s+", names=["D", "H", "T", "P"])
    data_list.append(df_temp)
data = pd.concat(data_list, ignore_index=True)

data["datetime"] = pd.to_datetime(data["D"] + " " + data["H"], format="%d-%m-%Y %H:%M")

# Inicializar la primera semana
fecha_lun = datetime.strptime('2025-01-20 00:00', '%Y-%m-%d %H:%M')
fecha_dom = datetime.strptime('2025-01-26 23:59', '%Y-%m-%d %H:%M')

semana_num = 1

# Bucle para procesar semana por semana hasta alcanzar fecha_fin
while fecha_lun <= fecha_fin:
    # Esto toma solamente los datos que están entre las fechas que se colocan
    mask = (data["datetime"] >= fecha_lun) & (data["datetime"] <= fecha_dom)
    data_filtrada = data.loc[mask]
    
    # Esto lo copia a un archivo
    if not data_filtrada.empty:
        data_filtrada = data_filtrada.drop(columns=["datetime"])
        nombre_archivo = f"datos_filtrados_semana_{semana_num}.csv"
        data_filtrada.to_csv(nombre_archivo, index=False)
        print(f"Guardado: {nombre_archivo} con {len(data_filtrada)} registros")
    
    # Avanzar a la siguiente semana
    fecha_lun = fecha_lun + timedelta(days=7)
    fecha_dom = fecha_dom + timedelta(days=7)
    semana_num += 1

print("Proceso completado")
